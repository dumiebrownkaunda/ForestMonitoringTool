from django.apps import AppConfig


class LicencesConfig(AppConfig):
    name = 'Licences'
