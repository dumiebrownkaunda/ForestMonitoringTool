from django.shortcuts import render


def licences(request):
     return render(request, 'Licences/licences.html')
