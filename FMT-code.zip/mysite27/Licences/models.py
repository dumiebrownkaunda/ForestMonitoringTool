from django.db import models
from django.utils import timezone


class Licences(models.Model):
    Contractor_name = models.CharField(max_length=60)
    Type = models.CharField(max_length=60)
    issued_date = models.DateTimeField(default=timezone.now)
    expiry_date = models.DateTimeField(default=timezone.now)
