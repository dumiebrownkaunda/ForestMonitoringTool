from django.contrib import admin
from Licences.models import Licences


# Register your models here.
class LicencesAdmin(admin.ModelAdmin):

    list_display = ('issued_date', 'expiry_date', 'contractor_name', 'type')


admin.site.register(Licences)
