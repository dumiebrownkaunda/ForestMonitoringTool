from django.contrib import admin
from FMT.models import User


# Register your models here.
admin.site.index_title = "Welcome to Forest Monitoring Tool Portal"


class UserAdmin(admin.ModelAdmin):
    list_display = ('user', 'email', 'description', 'position', 'user_info', 'phone', 'website')

    def user_info(self, obj):
        return obj.description

    def get_queryset(self, request):
        queryset = super(UserAdmin, self).get_queryset(request)
        queryset = queryset.order_by('user', 'phone')
        return queryset

    user_info.short_description = 'Information'


admin.site.register(User, UserAdmin)




