from django.apps import AppConfig


class FmtConfig(AppConfig):
    name = 'FMT'
