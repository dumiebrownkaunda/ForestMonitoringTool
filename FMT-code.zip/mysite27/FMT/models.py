from django.db import models
from django.contrib.auth.models import User


# Create your models here.
class UserManager(models.Model):
    def get_queryset(self):
        return super(UserManager, self).get_queryset().filter(information='testing')


class User(models.Model):
    user = models.OneToOneField(User)
    description = models.CharField(max_length=100, default='')
    position = models.CharField(max_length=20,)
    website = models.URLField(default='')
    email = models.EmailField()
    phone = models.IntegerField(default='0')
    image = models.ImageField(upload_to='profile_image', blank=True)

    testing = UserManager()

    def __str__(self):
        return self.user.username
