from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserChangeForm


@login_required
def home(request):
     return render(request, 'FMT/home.html')


@login_required
def login(request):
    return render(request, 'FMT/login.html')


@login_required
def profile(request):
    args = {'user': request.user}
    return render(request, 'FMT/profile.html', args)


def edit_profile(request):
    if request.method == 'POST':
        form = UserChangeForm(request.POST, instance=request.user)

        if form.is_valid():
            form.save()
            return redirect('FMT:profile')
        else:
            form = UserChangeForm(instance=request.user)
            args = {'form': form}
            return render(request, 'FMT:edit_profile.html', args)


