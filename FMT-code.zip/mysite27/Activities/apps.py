from django.apps import AppConfig


class ActivitiesConfig(AppConfig):
    name = 'Activities'
