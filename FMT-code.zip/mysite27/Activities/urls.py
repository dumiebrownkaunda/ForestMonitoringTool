from django.conf.urls import url
from . import views


urlpatterns = [
    url(r'^$', views.activities),
    url(r'^Activities/$', {'template_name': 'Activities/activities.html'})

]
