from django.contrib import admin
from .models import Activities


class ActivitiesAdmin(admin.ModelAdmin):
    list_display = ('name', 'status', 'description', 'date_started', 'closing_date')
    list_filter = ('date_started', 'closing_date', 'name')
    search_fields = ('status', 'name', 'closing_date')


admin.site.register(Activities, ActivitiesAdmin)

