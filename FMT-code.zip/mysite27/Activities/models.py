from django.db import models
from django.utils import timezone


# Create your models here.
class Activities(models.Model):
    STATUS_CHOICES = (
        ('in_progress', 'IN_PROGRESS'),
        ('finished', 'FINISHED'),
    )
    name = models.CharField(max_length=100, default='')
    description = models.CharField(max_length=200, default='')
    date_started = models.DateTimeField(default=timezone.now)
    closing_date = models.DateTimeField(default=timezone.now)
    status = models.CharField(max_length=11, choices=STATUS_CHOICES)


class Meta:
        verbose_name_plural = "Activities"
